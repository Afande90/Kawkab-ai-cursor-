import {
  IconClock,
  IconHistory,
  IconPlayerPause,
  IconPlayerPlay,
  IconTrash,
} from "@tabler/icons-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { Fragment, useState } from "react";
import {
  PageEmpty,
  PageRows,
  PageSection,
} from "@/components/layout/page-shell";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogBody,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Item,
  ItemActions,
  ItemContent,
  ItemDescription,
  ItemFooter,
  ItemMedia,
  ItemTitle,
} from "@/components/ui/item";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { appConfig } from "@/lib/generated/application-config";
import { relativeTime } from "@/lib/relative-time";
import {
  deleteRoutineMutationOptions,
  runRoutineNowMutationOptions,
  setRoutineEnabledMutationOptions,
} from "@/lib/routines/mutations";
import {
  nothingIsFiring,
  type RoutineRecord,
  type RoutineRunRecord,
  routineRunsQueryOptions,
  routinesQueryOptions,
} from "@/lib/routines/queries";
import { cn } from "@/lib/utils";
import { queryClient } from "@/query-client";

/**
 * What the last-run cell says, and in what tone.
 *
 * `lastRun === null` and `lastRun.status === null` are different facts, and saying the wrong one
 * invents news: the first is "this routine has never finished a run," the second is "one is open
 * right now" — which is also what a run stuck open after repeated dispatch failures looks like from
 * here. Neither is a failure, so neither gets the destructive tone; only `status: "failed"` does.
 */
function lastRunLabel(lastRun: RoutineRecord["lastRun"]): {
  text: string;
  className: string;
  /** The chip's dot, which carries the tone so the text can stay readable. */
  dot: string;
} {
  if (lastRun === null) {
    return {
      text: "Hasn't run yet",
      className: "text-muted-foreground",
      dot: "bg-muted-foreground/40",
    };
  }
  if (lastRun.status === null) {
    return {
      text: "Running…",
      className: "text-muted-foreground",
      dot: "animate-pulse bg-muted-foreground",
    };
  }
  const when = lastRun.at ? relativeTime(lastRun.at) : "recently";
  if (lastRun.status === "failed") {
    return {
      text: `Failed ${when}`,
      className: "text-destructive",
      dot: "bg-destructive",
    };
  }
  if (lastRun.status === "skipped") {
    return {
      text: `Skipped ${when}`,
      className: "text-amber-600 dark:text-amber-500",
      dot: "bg-amber-500",
    };
  }
  if (lastRun.status === "succeeded") {
    return {
      text: `Ran ${when}`,
      className: "text-muted-foreground",
      dot: "bg-emerald-500",
    };
  }
  // An outcome this DTO doesn't recognise degrades to a neutral label rather than an invented
  // success — the contract typing (`RoutineRunOutcome | null`) makes a fourth outcome a build-time
  // error, but this is the runtime fallback if that ever slips through.
  return {
    text: `Finished ${when}`,
    className: "text-muted-foreground",
    dot: "bg-muted-foreground/40",
  };
}

/**
 * One fact about a routine, worn as a small pill so the footer reads as a row of states rather
 * than a sentence.
 */
function Chip({
  className,
  children,
}: {
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-border bg-background/60 px-2 py-0.5 text-xs",
        className,
      )}
    >
      {children}
    </span>
  );
}

const RUN_STATUS: Record<
  RoutineRunRecord["status"],
  { text: string; dot: string; className: string }
> = {
  running: {
    text: "Running",
    dot: "animate-pulse bg-muted-foreground",
    className: "",
  },
  succeeded: { text: "Succeeded", dot: "bg-emerald-500", className: "" },
  failed: {
    text: "Failed",
    dot: "bg-destructive",
    className: "text-destructive",
  },
  skipped: {
    text: "Skipped",
    dot: "bg-amber-500",
    className: "text-amber-600 dark:text-amber-500",
  },
  waiting: { text: "Waiting for you", dot: "bg-sky-500", className: "" },
};

/** Every firing of one routine, newest first, each linking to the thread it ran in. */
function RoutineRuns({ routine }: { routine: RoutineRecord }) {
  const runs = useQuery(routineRunsQueryOptions(routine.id));
  // Pending renders nothing: "No runs yet." would otherwise flash for the fetch.
  if (runs.isPending) return null;
  if (runs.error)
    return (
      <p className="text-destructive text-xs" role="alert">
        {runs.error.message}
      </p>
    );
  if (!runs.data?.length)
    return <p className="text-muted-foreground text-xs">No runs yet.</p>;
  return (
    <ul className="flex w-full flex-col gap-1.5">
      {runs.data.map((run) => {
        const status = RUN_STATUS[run.status] ?? RUN_STATUS.skipped;
        return (
          <li
            className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs"
            key={run.id}
          >
            <span
              className={cn(
                "inline-flex items-center gap-1.5",
                status.className,
              )}
            >
              <span className={cn("size-1.5 rounded-full", status.dot)} />
              {status.text}
            </span>
            <span className="text-muted-foreground">
              {run.source === "run_now"
                ? "Run now"
                : run.source === "trigger"
                  ? "Triggered"
                  : "Scheduled"}{" "}
              · {relativeTime(run.startedAt)}
            </span>
            {routine.channel.gone ? null : (
              <Link
                className="text-muted-foreground underline underline-offset-2 hover:text-foreground"
                params={{ channelId: routine.channel.id }}
                to="/channel/$channelId"
              >
                Open conversation
              </Link>
            )}
            {run.error ? (
              <span className="basis-full text-muted-foreground">
                {run.error}
              </span>
            ) : null}
          </li>
        );
      })}
    </ul>
  );
}

/**
 * The signed-in person's standing instructions: a switch to stop one taking effect, and a delete
 * that ends it for good.
 *
 * Scoped by `agentId` on a Bot's Routines page, unscoped on the Routines page. One query either way —
 * the list is owner-scoped and small, so the scope is a filter here rather than a second endpoint.
 */
export function RoutinesList({
  agentId,
  embedded = false,
}: {
  /** Show only the routines this Bot carries out. Absent shows all of the person's. */
  agentId?: string;
  /** Where the page section's own top margin is somebody else's spacing. */
  embedded?: boolean;
} = {}) {
  const routines = useQuery(routinesQueryOptions());
  const setEnabled = useMutation(setRoutineEnabledMutationOptions(queryClient));
  const deleteRoutine = useMutation(deleteRoutineMutationOptions(queryClient));
  const runNow = useMutation(runRoutineNowMutationOptions(queryClient));
  /** Which routine's run history is open. One at a time keeps the list scannable. */
  const [historyId, setHistoryId] = useState<string | null>(null);
  /** The routine a delete is being confirmed for, or null. Its own dialog rather than one per row. */
  const [confirmingId, setConfirmingId] = useState<string | null>(null);
  const rows = (routines.data?.routines ?? []).filter(
    (row) => agentId === undefined || row.agentId === agentId,
  );
  const sweep = routines.data?.sweep;
  const noWorker = nothingIsFiring(sweep, rows.length);
  const confirming = rows.find((row) => row.id === confirmingId) ?? null;

  return (
    <PageSection className={embedded ? "mt-0" : undefined}>
      {setEnabled.error || runNow.error ? (
        <p className="mt-4 text-destructive text-sm" role="alert">
          {setEnabled.error?.message ?? runNow.error?.message}
        </p>
      ) : null}

      {/* A fact about the deployment rather than a row to act on, so said as a sentence. */}
      {noWorker ? (
        <p className="mt-4 text-muted-foreground text-sm" role="alert">
          <span className="font-medium text-amber-600 dark:text-amber-500">
            Routines aren't running.
          </span>{" "}
          {sweep?.lastSweptAt
            ? `${appConfig.brand.productName} last checked them ${relativeTime(sweep.lastSweptAt)}. None will run until it starts again. Ask an admin if this keeps happening.`
            : `${appConfig.brand.productName} hasn't started running routines yet, so none of these will run. Ask an admin to set this up.`}
        </p>
      ) : null}

      {/* Pending renders nothing: the empty-state sentence would otherwise flash for the fetch. */}
      {routines.isPending ? null : routines.error ? (
        <p className="mt-4 text-destructive text-sm" role="alert">
          Couldn't load your routines. Reload the page.
        </p>
      ) : rows.length === 0 ? (
        <PageEmpty>
          {agentId
            ? 'No routines for this Bot yet. Ask it something like "every weekday at 9, send me…" and it shows up here.'
            : 'No routines yet. Ask a Bot something like "every weekday at 9, send me…" and it shows up here.'}
        </PageEmpty>
      ) : (
        <PageRows>
          {rows.map((routine, index) => {
            const lastRun = lastRunLabel(routine.lastRun);
            return (
              <Fragment key={routine.id}>
                {index > 0 ? <Separator /> : null}
                <Item size="sm">
                  <ItemMedia variant="icon">
                    {routine.enabled ? <IconClock /> : <IconPlayerPause />}
                  </ItemMedia>
                  {/* Paused reads at a glance: the content dims, and a chip below says the word. */}
                  <ItemContent className={routine.enabled ? "" : "opacity-60"}>
                    <ItemTitle>
                      {routine.schedule}
                      <span className="font-normal text-muted-foreground text-xs">
                        {routine.timezone}
                      </span>
                    </ItemTitle>
                    <ItemDescription>{routine.instruction}</ItemDescription>
                  </ItemContent>
                  <ItemActions>
                    {/*
                     * Binary and immediate: it takes effect when switched, there is no save.
                     * Disabled only while its own write is in flight, so switching one routine
                     * does not freeze the rest of the list — the same idiom the per-tool plugins
                     * page uses for its per-Bot grant switches.
                     */}
                    <Switch
                      aria-label={`Enable the routine scheduled ${routine.schedule}`}
                      checked={routine.enabled}
                      disabled={
                        setEnabled.isPending &&
                        setEnabled.variables?.id === routine.id
                      }
                      onCheckedChange={(next) =>
                        setEnabled.mutate({ id: routine.id, enabled: next })
                      }
                    />
                  </ItemActions>
                  {/* Two sets — where it stands, and what can be done to it — so they wrap onto a
                      line of their own rather than crowding the title. */}
                  <ItemFooter className="flex-wrap">
                    <div
                      className={cn(
                        "flex flex-wrap items-center gap-1.5",
                        routine.enabled ? "" : "opacity-60",
                      )}
                    >
                      {routine.channel.gone ? (
                        <Chip className="border-destructive/40 text-destructive">
                          Conversation deleted
                        </Chip>
                      ) : (
                        // Where it posts is a place, so the chip goes there.
                        <Link
                          params={{ channelId: routine.channel.id }}
                          to="/channel/$channelId"
                        >
                          <Chip className="text-muted-foreground transition-colors hover:text-foreground">
                            {routine.channel.name ?? "Untitled conversation"}
                          </Chip>
                        </Link>
                      )}
                      <Chip className={lastRun.className}>
                        <span
                          className={cn("size-1.5 rounded-full", lastRun.dot)}
                        />
                        {lastRun.text}
                      </Chip>
                      {/*
                       * Enabled only: the store recomputes nextRunAt on cron/timezone change or
                       * re-enable, so a disabled routine's stamp is frozen in the past — rendering
                       * it unguarded would announce a stale "3 days ago" as the next run. Paused
                       * takes its place, so the switch's state has a word as well as a position.
                       */}
                      {!routine.enabled ? (
                        <Chip className="text-muted-foreground">Paused</Chip>
                      ) : new Date(routine.nextRunAt).getTime() <=
                        Date.now() ? (
                        /*
                         * A stamp in the past is a firing the sweep has not picked up, and "Next 5
                         * hours ago" is nonsense. Said as what it is: due, and visibly waiting.
                         */
                        <Chip className="text-amber-600 dark:text-amber-500">
                          <span className="size-1.5 animate-pulse rounded-full bg-amber-500" />
                          Due
                        </Chip>
                      ) : (
                        <Chip className="text-muted-foreground">
                          Next {relativeTime(routine.nextRunAt)}
                        </Chip>
                      )}
                    </div>
                    <div className="flex items-center gap-1">
                      {/*
                       * Run now is the Test button, and it does real work: the Bot carries out the
                       * instruction in the channel right away. Offered only while the routine is
                       * on, because a paused routine never runs.
                       */}
                      <Button
                        aria-label={`Run the routine scheduled ${routine.schedule} now`}
                        disabled={
                          !routine.enabled ||
                          (runNow.isPending && runNow.variables === routine.id)
                        }
                        onClick={() =>
                          runNow.mutate(routine.id, {
                            onSuccess: () => setHistoryId(routine.id),
                          })
                        }
                        size="sm"
                        title={
                          routine.enabled
                            ? "Runs it now, for real. The Bot does the work and posts in the conversation."
                            : "This routine is paused. Turn it on first."
                        }
                        type="button"
                        variant="outline"
                      >
                        <IconPlayerPlay />
                        Run now
                      </Button>
                      <Button
                        aria-expanded={historyId === routine.id}
                        aria-label={`Run history for the routine scheduled ${routine.schedule}`}
                        onClick={() =>
                          setHistoryId(
                            historyId === routine.id ? null : routine.id,
                          )
                        }
                        size="sm"
                        type="button"
                        variant="ghost"
                      >
                        <IconHistory />
                        History
                      </Button>
                      <Button
                        aria-label={`Delete the routine scheduled ${routine.schedule}`}
                        onClick={() => {
                          deleteRoutine.reset();
                          setConfirmingId(routine.id);
                        }}
                        size="sm"
                        type="button"
                        variant="ghost"
                      >
                        <IconTrash />
                        Delete
                      </Button>
                    </div>
                  </ItemFooter>
                  {historyId === routine.id ? (
                    <div className="basis-full border-border border-t pt-2">
                      <RoutineRuns routine={routine} />
                    </div>
                  ) : null}
                </Item>
              </Fragment>
            );
          })}
        </PageRows>
      )}

      {/*
       * One dialog for the whole list rather than one per row, keyed by which routine is being
       * confirmed. It names the schedule, not the id or the instruction, because the schedule is
       * the word a person reads first on the row and the one most likely to tell two routines apart
       * at a glance.
       */}
      <Dialog
        onOpenChange={(open) => {
          if (!open) setConfirmingId(null);
        }}
        open={confirming !== null}
      >
        {/* The heavier backdrop, forced: opened from a Bot's dialog this stacks over it, and Base
            UI would otherwise render a nested dialog with no backdrop at all. */}
        <DialogContent overlayClassName="bg-black/20 supports-backdrop-filter:backdrop-blur-sm">
          <DialogHeader>
            <DialogTitle>Delete "{confirming?.schedule}"?</DialogTitle>
            <DialogDescription>
              This routine stops for good. You can't undo this.
            </DialogDescription>
          </DialogHeader>
          {deleteRoutine.error ? (
            <DialogBody className="mt-4">
              <p className="text-destructive text-sm" role="alert">
                {deleteRoutine.error.message}
              </p>
            </DialogBody>
          ) : null}
          <DialogFooter className="mt-4">
            <Button
              onClick={() => setConfirmingId(null)}
              size="sm"
              type="button"
              variant="outline"
            >
              Cancel
            </Button>
            <Button
              disabled={deleteRoutine.isPending}
              onClick={() => {
                if (!confirmingId) return;
                deleteRoutine.mutate(confirmingId, {
                  onSuccess: () => setConfirmingId(null),
                });
              }}
              size="sm"
              type="button"
              variant="destructive"
            >
              {deleteRoutine.isPending ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </PageSection>
  );
}
