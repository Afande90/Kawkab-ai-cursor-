import { OpenGenerativeUIActivityRenderer } from "@copilotkit/react-core/v2";
import { useQuery } from "@tanstack/react-query";
import { type ReactNode, useEffect, useRef, useState } from "react";
import { galleryComponent } from "@/lib/copilot/gallery-registry";
import {
  type SandboxedRecord,
  sandboxedListQueryOptions,
} from "@/lib/sandboxed/queries";

/** Sample arguments belong to the administrator's working copy, so only Admin fetches them. */
export function AdminComponentPreview({
  name,
  kind,
}: {
  name: string;
  kind: string;
}) {
  const sandboxed = useQuery({
    ...sandboxedListQueryOptions(),
    enabled: kind === "sandboxed",
  });
  if (kind === "sandboxed" && sandboxed.isPending) return null;
  if (kind === "sandboxed" && sandboxed.error) {
    return <PreviewNotice>Preview could not be loaded.</PreviewNotice>;
  }
  return (
    <ComponentPreview
      kind={kind}
      name={name}
      sandboxed={sandboxed.data?.find((component) => component.name === name)}
    />
  );
}

function PreviewNotice({ children }: { children: ReactNode }) {
  return (
    <div className="flex h-full w-full items-center justify-center p-4">
      {/* The artwork stays pale in both themes, so this text must stay dark. */}
      <p className="text-center text-neutral-700 text-xs">{children}</p>
    </div>
  );
}

export function ComponentPreview({
  name,
  kind,
  sandboxed,
  fill = PREVIEW_FILL,
}: {
  name: string;
  kind?: string;
  sandboxed?: SandboxedRecord;
  fill?: number;
}) {
  const entry = galleryComponent(name);
  if (entry?.preview) {
    return (
      <FittedPreview fill={fill}>
        <entry.Component {...entry.preview} />
      </FittedPreview>
    );
  }

  if (sandboxed?.name === name) {
    if (!sandboxed.published || sandboxed.publishedHtml === null) {
      return (
        <PreviewNotice>
          Publish in the playground to see a preview.
        </PreviewNotice>
      );
    }
    const content = {
      css: sandboxed.publishedCss ?? "",
      cssComplete: true,
      html: [sandboxed.publishedHtml],
      htmlComplete: true,
      jsFunctions: `window.__args = ${JSON.stringify(sandboxed.sampleArguments)};\n${sandboxed.publishedJsFunctions ?? ""}`,
      jsFunctionsComplete: true,
      generating: false,
    };
    return (
      <FittedPreview fill={fill}>
        <div
          className="w-full"
          title="Published component with saved sample arguments"
        >
          <OpenGenerativeUIActivityRenderer
            activityType="open-generative-ui"
            agent={null}
            content={content}
            key={JSON.stringify(content)}
            message={null}
          />
        </div>
      </FittedPreview>
    );
  }

  return (
    <PreviewNotice>
      {entry
        ? "This one is only drawn in a conversation."
        : kind === "sandboxed"
          ? "Published in the playground."
          : "This build cannot draw this."}
    </PreviewNotice>
  );
}

/**
 * The width a gallery component is given to lay out against, standing in for the conversation
 * column: previewing at the tile's own width would be a different component.
 *
 * Only an upper bound, and deliberately not read as the component's width. `GalleryFrame` caps
 * itself at `max-w-2xl`, which is 42rem: 672px at the browser's default text size, and more or
 * less for a person who changed it. When the app's root was 15px it was 630px, and assuming the
 * number left every preview sitting half the difference off centre, so the drawn width is measured.
 */
const PREVIEW_LAYOUT_WIDTH = 672;

/**
 * How much of the space it could fill a preview actually takes, leaving the rest as margin.
 *
 * Padding the tile instead would not do it: the fit is measured against whichever axis runs out
 * first, so a component that binds on height would still meet the top and bottom edges. Holding it
 * off every edge means taking a share of the room on both axes at once.
 */
export const PREVIEW_FILL = 0.85;

/**
 * One component, drawn at its real size and scaled to sit inside the tile.
 *
 * The scale is measured rather than declared. CSS cannot do it: `scale()` needs a unitless number
 * and `calc()` will not divide a length by one, so a container query cannot produce the ratio — and
 * a hard-coded ratio would be wrong as soon as the tile changes shape.
 *
 * It is measured against both axes, because a component's height is its own business: a donut chart
 * and a five-line checklist are the same width and nothing like the same height. Fitting on width
 * alone left the tall ones running out of the bottom of the tile.
 *
 * Never scaled past its natural size, then held to `fill` of what it could fill. A box wider than a
 * conversation column would otherwise magnify a component beyond the size anybody will actually see
 * it at.
 *
 * Drawn inert and hidden from assistive technology. These are the real components, so a decision
 * card here has a real note field and real Approve and Decline buttons; nothing in Admin should be
 * able to reach them, and a screen reader should not find a second set of them on the page.
 */
function FittedPreview({
  children,
  fill,
}: {
  children: ReactNode;
  fill: number;
}) {
  const box = useRef<HTMLDivElement>(null);
  const content = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(0);

  useEffect(() => {
    const outer = box.current;
    const inner = content.current;
    if (!outer || !inner) return;

    const measure = () => {
      /*
       * Measured on the component's own root rather than the box it was handed, because the two are
       * not the same width: the box is the column it lays out against, and the component caps
       * itself inside that. Scaling by the box would shrink it to fit a width it never occupied.
       *
       * `offsetWidth` and `offsetHeight` are laid-out values, which a transform does not touch — so
       * reading them here cannot feed back into the scale about to be applied to them.
       */
      const drawn = inner.firstElementChild;
      const measured = drawn instanceof HTMLElement ? drawn : inner;

      if (!measured.offsetWidth || !measured.offsetHeight) return;
      if (!outer.clientWidth || !outer.clientHeight) return;

      setScale(
        fill *
          Math.min(
            1,
            outer.clientWidth / measured.offsetWidth,
            outer.clientHeight / measured.offsetHeight,
          ),
      );
    };

    const observer = new ResizeObserver(measure);
    observer.observe(outer);
    observer.observe(inner);
    return () => observer.disconnect();
  }, [fill]);

  return (
    <div
      aria-hidden="true"
      className="flex h-full w-full items-center justify-center overflow-hidden"
      inert
      ref={box}
    >
      {/*
       * Centred by the flex parent and scaled about its own middle. The layout box stays full size
       * and may be larger than the tile, which is what keeps it centred: shrinking happens around
       * the centre point the parent already placed.
       *
       * A flex row itself, so a component narrower than the column it was given is centred in it
       * rather than left against one edge. Whatever `max-w-2xl` resolves to, the slack is split.
       */}
      <div
        className="flex shrink-0 justify-center transition-opacity"
        ref={content}
        style={{
          // Until the tile has been measured there is no honest scale, so draw nothing.
          opacity: scale > 0 ? 1 : 0,
          transform: `scale(${scale})`,
          width: PREVIEW_LAYOUT_WIDTH,
        }}
      >
        {children}
      </div>
    </div>
  );
}
