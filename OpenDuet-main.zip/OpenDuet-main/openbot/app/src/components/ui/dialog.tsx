import { Dialog as DialogPrimitive } from "@base-ui/react/dialog";
import { IconX } from "@tabler/icons-react";
import type * as React from "react";

import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

/**
 * A centred modal, for a form that is short enough to finish in one sitting.
 *
 * WHY THIS EXISTS ALONGSIDE `DetailPanel`. The panel is the right answer on the screens somebody
 * lives in — writing a skill, editing an agent — where the list stays visible beside what you are
 * editing and the work is worth a URL. Admin is not that: a credential is added once and forgotten,
 * and giving it a route and a side panel dresses a two-field form as a place you might come back to.
 *
 * Built on the same Base UI dialog as `Sheet`, so focus trapping, scroll locking and the escape key
 * behave identically across the app rather than nearly identically.
 */
function Dialog({ ...props }: DialogPrimitive.Root.Props) {
  return <DialogPrimitive.Root data-slot="dialog" {...props} />;
}

function DialogTrigger({ ...props }: DialogPrimitive.Trigger.Props) {
  return <DialogPrimitive.Trigger data-slot="dialog-trigger" {...props} />;
}

function DialogClose({ ...props }: DialogPrimitive.Close.Props) {
  return <DialogPrimitive.Close data-slot="dialog-close" {...props} />;
}

function DialogPortal({ ...props }: DialogPrimitive.Portal.Props) {
  return <DialogPrimitive.Portal data-slot="dialog-portal" {...props} />;
}

function DialogOverlay({
  className,
  ...props
}: DialogPrimitive.Backdrop.Props) {
  return (
    <DialogPrimitive.Backdrop
      data-slot="dialog-overlay"
      className={cn(
        "fixed inset-0 z-50 bg-black/10 transition-opacity duration-[var(--duet-dur-enter)] data-ending-style:duration-[var(--duet-dur-tap)] data-ending-style:opacity-0 data-starting-style:opacity-0 supports-backdrop-filter:backdrop-blur-xs",
        className,
      )}
      {...props}
    />
  );
}

function DialogContent({
  className,
  overlayClassName,
  children,
  showCloseButton = true,
  ...props
}: DialogPrimitive.Popup.Props & {
  showCloseButton?: boolean;
  /**
   * Restyles the backdrop behind this popup. A dialog stacked over another passes a heavier one
   * here, so the dialog underneath reads as background rather than as a competing surface.
   *
   * Setting this also forces the backdrop to exist: Base UI skips backdrops on nested dialogs,
   * and a stacked dialog is precisely the caller that asks for one.
   */
  overlayClassName?: string;
}) {
  return (
    <DialogPortal>
      <DialogOverlay
        className={overlayClassName}
        forceRender={overlayClassName !== undefined}
      />
      <DialogPrimitive.Popup
        data-slot="dialog-content"
        className={cn(
          /*
           * `max-h-[85svh]` with the body scrolling, not the popup growing: a form that is long on a
           * laptop must not push its own submit button off the bottom of the screen, which is exactly
           * where somebody looks for it.
           *
           * It opens from 96% at the entrance duration and closes to 98% at the tap one: leaving, it
           * only needs to be seen going. With reduced motion it fades without the scale.
           */
          "-translate-x-1/2 -translate-y-1/2 fixed top-1/2 left-1/2 z-50 flex max-h-[85svh] w-[calc(100%-2rem)] max-w-lg flex-col gap-4 rounded-xl border border-border bg-popover p-5 text-sm text-popover-foreground shadow-lg transition-[opacity,scale] duration-[var(--duet-dur-enter)] data-ending-style:duration-[var(--duet-dur-tap)] data-ending-style:opacity-0 data-starting-style:opacity-0 motion-safe:data-ending-style:scale-[0.98] motion-safe:data-starting-style:scale-[0.96]",
          className,
        )}
        {...props}
      >
        {children}
        {showCloseButton && (
          <DialogPrimitive.Close
            data-slot="dialog-close"
            render={
              <Button
                variant="ghost"
                className="absolute top-3 right-3"
                size="icon-sm"
              />
            }
          >
            <IconX />
            <span className="sr-only">Close</span>
          </DialogPrimitive.Close>
        )}
      </DialogPrimitive.Popup>
    </DialogPortal>
  );
}

function DialogHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="dialog-header"
      className={cn("flex flex-col gap-1 pr-8", className)}
      {...props}
    />
  );
}

/**
 * Body scrolls, so the header and footer stay put on a short viewport.
 *
 * `overflow-y-auto` is the half that was missing. `flex-1 min-h-0` lets this shrink, but without an
 * overflow it shrinks and then paints its content over the footer — which every dialog here was short
 * enough never to show.
 */
function DialogBody({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="dialog-body"
      className={cn(
        "-mx-1 flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto px-1",
        className,
      )}
      {...props}
    />
  );
}

function DialogFooter({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="dialog-footer"
      className={cn("flex flex-row items-center justify-end gap-2", className)}
      {...props}
    />
  );
}

function DialogTitle({ className, ...props }: DialogPrimitive.Title.Props) {
  return (
    <DialogPrimitive.Title
      data-slot="dialog-title"
      className={cn(
        "font-heading font-medium text-base text-foreground",
        className,
      )}
      {...props}
    />
  );
}

function DialogDescription({
  className,
  ...props
}: DialogPrimitive.Description.Props) {
  return (
    <DialogPrimitive.Description
      data-slot="dialog-description"
      className={cn("text-muted-foreground text-sm text-pretty", className)}
      {...props}
    />
  );
}

export {
  Dialog,
  DialogBody,
  DialogClose,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogOverlay,
  DialogPortal,
  DialogTitle,
  DialogTrigger,
};
