import { IconChevronLeft } from "@tabler/icons-react";
import { Link, type LinkProps } from "@tanstack/react-router";
import type * as React from "react";
import { useInPageChrome, usePageChrome } from "@/components/shell/page-chrome";
import { cn } from "@/lib/utils";
import { Button } from "../ui/button";
import { SidebarToggle, useSidebarToggleVisible } from "./sidebar-toggle";

/**
 * The frame every configuration screen sits in.
 *
 * WHAT THIS IS FIXING. Admin was nine pages that shared no layout: four container widths plus three
 * pages with no container at all, four heading sizes, four padding schemes, and a sidebar 20px wider
 * than the rest of the app. Three of those pages imported nothing from `components/ui` and drew
 * their own buttons, inputs and tables. The result did not read as a different screen, it read as a
 * different application — which is the impression an administrator forms at exactly the moment they
 * are deciding whether to trust it with credentials.
 *
 * The shape was never in doubt: Skills and Settings already had it. So this is that shape, extracted
 * once and used everywhere, INCLUDING by Skills and Settings. Leaving those two as hand-written
 * copies would mean three dialects rather than two, and the next screen somebody writes copies
 * whichever it happened to see first.
 */

/**
 * `prose` is the default because configuration is mostly reading, and every screen uses it so none is
 * wider than another. It is `max-w-3xl`, 768px against the browser's 16px root: room for a row's label
 * and its control side by side. Sentences are held to `max-w-prose` (around 65 characters) inside it,
 * which is where reading stays comfortable, so the column widening does not stretch them.
 *
 * `wide` exists for one page. An audit log is a table you scan, and forcing it into the prose column
 * would wrap every row. It is not a licence for anything else to be wide.
 */
type ShellWidth = "prose" | "wide";

const WIDTHS: Record<ShellWidth, string> = {
  prose: "max-w-3xl",
  wide: "max-w-5xl",
};

export function PageShell({
  action,
  children,
  className,
  description,
  title,
  width = "prose",
  backButton,
}: {
  /** Sits on the title's baseline. For the page's one primary verb, if it has one. */
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  description?: React.ReactNode;
  title: string;
  width?: ShellWidth;
  backButton?: {
    linkProps: LinkProps;
    label: string;
  };
}) {
  /*
   * The bar carries the toggle and the Back link, and is drawn when it has at least one of them.
   * The screens with a Back link already drew exactly this bar, so for them nothing changes; what
   * changed is that a sidebar is now reason enough on its own, because the toggle has to sit at the
   * pane's left edge in both states and the prose column is centred — a control inside it would be
   * 400px from the edge it belongs to on a wide screen. Drawing it with neither would be a 56px
   * band holding nothing, which reads as a layout bug rather than as chrome.
   *
   * The question is whether the toggle will DRAW, not whether a sidebar exists: it hides itself on
   * a desktop-width window while the sidebar is already open, which is most of the time on these
   * screens. Asking `useSidebarToggleVisible` rather than re-deriving the condition here is what
   * keeps the two from drifting apart and reintroducing that empty band. It also still answers false
   * on `/assist` and `/link/slack`, which draw PageShell directly under `_authed` with no sidebar
   * provider at all, so there is nothing for a toggle to act on there.
   */
  const showToggle = useSidebarToggleVisible();
  /*
   * UNDER THE APP'S PAGE CHROME the shell draws the back disc and the title (parity-spec 2.9), so
   * this draws neither: no bar, and the heading kept for screen readers only. The Back link this page
   * was given becomes where the disc goes when there is no history to go back through.
   */
  const inChrome = useInPageChrome();
  usePageChrome({
    title,
    ...(backButton ? { backTo: backButton.linkProps } : {}),
  });
  const bar = !inChrome && (showToggle || !!backButton);

  return (
    <>
      {bar ? (
        <div className="max-w-7xl w-full h-14 flex items-center gap-1 px-3">
          {showToggle ? <SidebarToggle /> : null}
          {!!backButton && (
            <Button
              variant="ghost"
              render={(props) => <Link {...backButton.linkProps} {...props} />}
            >
              <IconChevronLeft />
              {backButton.label}
            </Button>
          )}
        </div>
      ) : null}
      {/*
       * The scroller, and it has to live here rather than in either shell, because the two shells
       * this frame is used under disagree about who scrolls.
       *
       * Under `_authed` — admin, settings — the document scrolls, so a page taller than the window
       * has always just worked. Under `_authed/_app` it does not: that shell is `h-svh
       * overflow-hidden` on purpose ("one viewport, never scrolls: panes scroll inside it") and its
       * `main` is `overflow-hidden` too, so a PageShell taller than the window was silently CLIPPED
       * — 246px of Skills sat below the fold with no way to reach it, by keyboard or otherwise.
       *
       * `min-h-0` is the load-bearing half of `min-h-0 flex-1`: a flex item's default `min-height:
       * auto` refuses to shrink below its content, so `flex-1` alone would grow this past the pane
       * and clip exactly as before. Under `_authed` both are inert — the parent is not a flex
       * container — and `overflow-y-auto` on an auto-height element shows no scrollbar, so those
       * eighteen screens are unaffected.
       *
       * Separate from the centred column below so the scrollbar rides the pane's edge instead of
       * appearing inside a 768px measure with content either side of it.
       */}
      <div className="min-h-0 flex-1 overflow-y-auto">
        <div
          className={cn(
            "mx-auto flex w-full flex-col px-4 pb-12",
            // Under the chrome the page starts below its floating header. Without a bar above it
            // the heading keeps the full original space.
            inChrome ? "pt-[92px]" : bar ? "pt-8" : "pt-12",
            WIDTHS[width],
            className,
          )}
        >
          <header className="flex flex-col gap-2">
            <div
              className={cn(
                "flex flex-row items-center justify-between gap-4",
                inChrome && !action && "sr-only",
              )}
            >
              <h1
                className={cn(
                  "type-display font-semibold",
                  inChrome && "sr-only",
                )}
              >
                {title}
              </h1>
              {action}
            </div>
            {description ? (
              <p className="type-sub max-w-prose text-pretty text-muted-foreground">
                {description}
              </p>
            ) : null}
          </header>
          {children}
        </div>
      </div>
    </>
  );
}

/**
 * A titled group of rows.
 *
 * The gap above a section is deliberately large. These pages are lists of unrelated decisions, and
 * the space is what stops the eye running two of them together — it is doing the work a divider
 * would otherwise do, without drawing a line.
 */
export function PageSection({
  action,
  children,
  className,
  description,
  title,
}: {
  action?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
  description?: React.ReactNode;
  title?: string;
}) {
  return (
    <section className={cn("mt-12", className)}>
      {title ? (
        <div className="flex min-h-8 flex-row items-center justify-between gap-4">
          {/* Section headers recede so the rows lead (parity-spec 2.3): the sub size, not bold. */}
          <h2 className="type-sub font-medium text-muted-foreground">
            {title}
          </h2>
          {action}
        </div>
      ) : null}
      {description ? (
        <p className="type-sub mt-1 max-w-prose text-pretty text-muted-foreground">
          {description}
        </p>
      ) : null}
      {children}
    </section>
  );
}

/**
 * The card that rows live in.
 *
 * Rows are `<Item size="sm">` with a `<Separator />` between them; this is only the border around
 * them. Rendering nothing when there is nothing is deliberate — an empty bordered box reads as a
 * thing that failed to load, where absence reads as nothing to see yet.
 */
export function PageRows({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    /*
     * The rows are squared off and the card clips them. `Item` carries `rounded-lg` of its own, which
     * inside a card of divided rows painted a hover as a floating pill: a middle row has no corners,
     * and the first and last cannot be concentric with the card while sitting a border inside it.
     */
    <div
      className={cn(
        "mt-4 overflow-hidden rounded-lg border border-border bg-card dark:border-transparent",
        "[&_[data-slot=item]]:rounded-none",
        className,
      )}
    >
      {children}
    </div>
  );
}

/**
 * What a section says when it has nothing to list.
 *
 * Said in a sentence rather than drawn as an illustration with a heading: on a configuration screen
 * "nothing here yet" is a fact, not an event, and the page already told you what the section is for.
 */
export function PageEmpty({ children }: { children: React.ReactNode }) {
  return <p className="type-sub mt-4 text-muted-foreground">{children}</p>;
}
